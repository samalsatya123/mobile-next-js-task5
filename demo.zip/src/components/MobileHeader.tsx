import Image from 'next/image';

const signalBars = [
  { height: "h-[5px]", top: "top-2", left: "left-0" },
  { height: "h-[7px]", top: "top-1.5", left: "left-1.5" },
  { height: "h-2.5", top: "top-[3px]", left: "left-[11px]" },
  { height: "h-3", top: "top-px", left: "left-4" },
];

export function MobileHeader() {
  return (
    <header className="flex flex-col w-full bg-main-colorwhite shadow-header">
      <div className="relative w-full h-5">
        <div className="inline-flex items-center gap-1 absolute top-[3px] left-1">
          <div className="relative w-5 h-3.5">
            {signalBars.map((bar, index) => (
              <div
                key={`signal-bar-${index}`}
                className={`${bar.height} ${bar.top} ${bar.left} absolute w-[3px] bg-black rounded-[1px]`}
              />
            ))}
          </div>

          <div className="relative w-fit mt-[-1.00px] [font-family:'SF_Pro_Text-Medium',Helvetica] font-medium text-black text-xs tracking-[-0.12px] leading-[normal] whitespace-nowrap">
            Carrier
          </div>

          <div className="relative w-5 h-3">
            <Image
              className="absolute w-4 h-[11px] top-0 left-0.5"
              alt="Network signal"
              src="/group-3.png"
              width={16}
              height={11}
            />
          </div>
        </div>

        <div className="absolute top-[3px] left-[164px] [font-family:'SF_Pro_Text-Semibold',Helvetica] font-normal text-black text-xs text-center tracking-[-0.12px] leading-[normal] whitespace-nowrap">
          9:41 AM
        </div>

        <div className="inline-flex items-center justify-end gap-0.5 absolute top-0.5 left-[301px]">
          <div className="relative w-1.5 h-1.5" />

          <div className="relative w-fit mt-[-1.00px] [font-family:'SF_Pro_Text-Medium',Helvetica] font-medium text-black text-xs text-right tracking-[-0.12px] leading-[normal] whitespace-nowrap">
            100%
          </div>

          <div className="relative w-7 h-3.5">
            <div className="relative h-[13px]">
              <div className="absolute w-[21px] h-[9px] top-0.5 left-0.5 bg-black rounded-[1.33px]" />
              <Image
                className="absolute w-7 h-[13px] top-0 left-0"
                alt="Battery indicator"
                src="/battery-frame.svg"
                width={28}
                height={13}
              />
            </div>
          </div>
        </div>
      </div>

      <nav className="relative w-full h-[60px]">
        <div className="relative w-[360px] h-11 top-[7px] left-[7px]">
          <div className="absolute w-[30px] h-[30px] top-2 left-[13px] bg-[url(/mm-ui-back-150dpi.png)] bg-cover bg-[50%_50%]" />

          <div className="absolute w-[360px] h-11 top-0 left-0">
            <div className="h-11">
              <div className="w-[360px] h-11 bg-white">
                <div className="relative w-[346px] h-16 -top-2.5 left-2">
                  <Image
                    className="absolute w-[346px] h-[31px] top-4 left-0"
                    alt="Address bar frame"
                    src="/frame-2.svg"
                    width={346}
                    height={31}
                  />

                  <div className="absolute w-[278px] h-16 top-0 left-[30px]">
                    <div className="absolute w-2 h-3 top-[25px] left-0">
                      <div className="relative h-3">
                        <div className="absolute w-2 h-[7px] top-[5px] left-0 bg-black rounded-[1px]" />
                        <div className="absolute w-1.5 h-2.5 top-0 left-px rounded border border-solid border-black" />
                      </div>
                    </div>

                    <div className="absolute h-16 top-0 left-3.5 [font-family:'Inter',Helvetica] font-medium text-[#4c4c4c] text-[15px] tracking-[-0.15px] leading-[63.9px] whitespace-nowrap">
                      www.overseasgroup.com/s/lpf98708
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
}