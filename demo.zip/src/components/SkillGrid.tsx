import Image from 'next/image';
import { Skill } from '@/types/worker';
import { Card, CardContent } from './ui/card';

interface SkillGridProps {
  skills: Skill[];
}

export function SkillGrid({ skills }: SkillGridProps) {
  // Group skills into rows of 3
  const skillRows = [];
  for (let i = 0; i < skills.length; i += 3) {
    skillRows.push(skills.slice(i, i + 3));
  }

  return (
    <div className="inline-flex flex-col items-start gap-4 relative w-full">
      <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0.37px] leading-5 whitespace-nowrap">
        Main Skills
      </h2>
      <div className="flex flex-col w-full items-start gap-[13px] relative">
        {skillRows.map((row, rowIndex) => (
          <div
            key={rowIndex}
            className="flex items-start justify-between relative w-full"
          >
            {row.map((skill, skillIndex) => (
              <div key={skill.id} className="relative flex-1 h-[97px] mx-1">
                <Card className="relative w-full h-[97px] bg-white rounded-[10px] border border-solid border-[#0000000d] shadow-[0px_0px_10px_#0000000f]">
                  <CardContent className="p-0 relative w-full h-full">
                    <div className="absolute w-[50px] h-[51px] top-3 left-1/2 transform -translate-x-1/2">
                      <Image
                        src={skill.image}
                        alt={skill.title}
                        width={50}
                        height={51}
                        className="object-contain"
                      />
                    </div>
                    <div className="absolute w-full top-[61px] left-0 [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-black text-sm text-center tracking-[0] leading-3 px-2">
                      {skill.title}
                    </div>
                    {skill.subtitle && (
                      <div className="absolute w-full h-[15px] top-[75px] left-0 opacity-80 [font-family:'Mabry_Pro-Bold',Helvetica] font-bold text-[#9b9a9b] text-[10px] text-center tracking-[0.33px] leading-5 whitespace-nowrap">
                        {skill.subtitle}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}