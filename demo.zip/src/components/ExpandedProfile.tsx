'use client';

import { useState } from 'react';
import Image from 'next/image';
import { ExpandedProfileSection } from '@/types/worker';
import { Separator } from './ui/separator';
import * as Collapsible from '@radix-ui/react-collapsible';

interface ExpandedProfileProps {
  sections: ExpandedProfileSection[];
}

export function ExpandedProfile({ sections }: ExpandedProfileProps) {
  const [openSections, setOpenSections] = useState<Set<string>>(new Set());

  const toggleSection = (sectionId: string) => {
    const newOpenSections = new Set(openSections);
    if (newOpenSections.has(sectionId)) {
      newOpenSections.delete(sectionId);
    } else {
      newOpenSections.add(sectionId);
    }
    setOpenSections(newOpenSections);
  };

  return (
    <div className="flex flex-col w-full items-start gap-4 relative">
      <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0] leading-[normal] whitespace-nowrap">
        Expanded Profile
      </h2>
      <div className="flex flex-col items-start gap-3 relative w-full">
        {sections.map((section, sectionIndex) => (
          <div key={section.id} className="w-full">
            <Collapsible.Root
              open={openSections.has(section.id)}
              onOpenChange={() => toggleSection(section.id)}
            >
              <Collapsible.Trigger className="flex items-center justify-between relative w-full group">
                <div className="relative w-fit [font-family:'Mabry_Pro-Bold',Helvetica] font-bold text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                  {section.title}
                </div>
                <div 
                  className={`relative w-6 h-6 transition-transform duration-200 ${
                    openSections.has(section.id) ? 'rotate-0' : '-rotate-90'
                  }`}
                >
                  <Image
                    className="absolute w-6 h-6 top-0 left-0 object-cover"
                    alt="Expand section"
                    src="/mm-ui-chevron-150dpi-2.png"
                    width={24}
                    height={24}
                  />
                </div>
              </Collapsible.Trigger>

              <Collapsible.Content className="overflow-hidden data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down">
                {section.sections.map((subsection, subsectionIndex) => (
                  <div
                    key={subsectionIndex}
                    className="inline-flex flex-col items-start gap-1 relative mt-4"
                  >
                    <div className="relative w-[295px] mt-[-1.00px] [font-family:'Mabry_Pro-Bold',Helvetica] font-bold text-[#898989] text-[10px] tracking-[0] leading-5">
                      {subsection.label}
                    </div>
                    <div className="relative w-[295px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-6 whitespace-pre-line">
                      {subsection.content}
                    </div>
                  </div>
                ))}
              </Collapsible.Content>
            </Collapsible.Root>

            {sectionIndex < sections.length - 1 && (
              <Separator className="relative w-full ml-[-0.50px] mr-[-0.50px] h-px mt-4" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}