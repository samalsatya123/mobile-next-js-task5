interface InfoCardProps {
  title: string;
  data: Array<Array<{ label: string; value: string }>> | Array<{ label: string; value: string }>;
}

export function InfoCard({ title, data }: InfoCardProps) {
  // Normalize data into rows. Accept either a 2D array or a flat array of items.
  const rows: Array<Array<{ label: string; value: string }>> =
    Array.isArray(data) && data.length > 0 && Array.isArray(data[0])
      ? (data as Array<Array<{ label: string; value: string }>>)
      : [(data as Array<{ label: string; value: string }>)];

  return (
    <div className="flex flex-col items-start gap-4 relative w-full">
      <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0] leading-[normal] whitespace-nowrap">
        {title}
      </h2>
      <div className="flex flex-col w-full items-start gap-5 relative">
        {rows.map((row, rowIndex) => (
          <div key={rowIndex} className="inline-flex items-start justify-center gap-px relative w-full">
            {row.map((item, itemIndex) => (
              <div key={itemIndex} className="inline-flex flex-col items-center gap-1 relative flex-1">
                <div className="relative w-full mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] text-center">
                  {item.label}
                </div>
                <div className="relative w-full [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] text-center">
                  {item.value}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
