import Image from 'next/image';
import { WorkerDetail } from '@/types/worker';

interface ProfileHeaderProps {
  worker: WorkerDetail;
}

const headerStats = [
  {
    icon: "/mm-work-experience-150dpi-1.png",
    label: "Experience",
    key: "yearsOfExperience" as keyof WorkerDetail,
    suffix: " Years",
  },
  {
    icon: "/mm-helper-start-date-helper-start-date-150dpi.png",
    label: "Can Start",
    key: "canStartDate" as keyof WorkerDetail,
    suffix: "",
  },
  {
    icon: "/mm-current-location-current-location-150dpi.png",
    label: "Location",
    key: "location" as keyof WorkerDetail,
    suffix: "",
  },
];

export function ProfileHeader({ worker }: ProfileHeaderProps) {
  if (process.env.NEXT_PUBLIC_SHOW_HEADER === 'false') {
    return null;
  }
  return (
    <div className="relative bg-white">
      <div className="relative w-full h-[203px]">
        <div className="absolute w-full h-[180px] top-0 left-0">
          <Image
            src={worker.backgroundImage}
            alt="Profile background"
            fill
            className="object-cover"
            priority
          />
        </div>

        <div className="absolute w-[130px] h-[130px] top-[73px] left-1/2 transform -translate-x-1/2 bg-main-colorwhite rounded-[65px] border border-solid border-[#eaeaea] shadow-white-button-shadow">
          <div className="relative w-[118px] h-[118px] top-[5px] left-[5px] rounded-[118px] overflow-hidden">
            <Image
              src={worker.profileImage}
              alt={`${worker.name} profile picture`}
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center mt-[19px] mb-6">
        <h1 className="relative w-fit mt-[-1.00px] [font-family:'Cooper_BT-Light',Helvetica] font-light text-neutrals-colorneutrals-black text-[28px] text-center tracking-[0] leading-[normal]">
          {worker.name}
        </h1>

        <p className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-base text-center tracking-[0] leading-[normal] whitespace-nowrap">
          {worker.age}, {worker.nationality}
        </p>
      </div>

      <div className="flex w-full h-20 items-start justify-between relative px-5 mb-6">
        {headerStats.map((stat, index) => (
          <div key={index} className="relative flex-1 h-[78px]">
            <div
              className="absolute w-[34px] h-[34px] top-0 left-1/2 transform -translate-x-1/2 bg-cover bg-center"
              style={{ backgroundImage: `url(${stat.icon})` }}
            />
            <div className="flex flex-col w-full items-center gap-1 absolute top-11 left-0">
              <div className="relative text-center mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-grey-4 text-sm tracking-[0] leading-[normal]">
                {stat.label}
              </div>
  <div className="relative text-center [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal]">
    {String((worker as any)[stat.key])}{stat.suffix}
  </div>
            </div>
          </div>
        ))}
      </div>

      <div className="relative w-full px-5">
        <Image
          className="w-full h-px object-cover mb-6"
          alt="Divider"
          src="/vector-13.svg"
          width={335}
          height={1}
        />
      </div>
    </div>
  );
}
