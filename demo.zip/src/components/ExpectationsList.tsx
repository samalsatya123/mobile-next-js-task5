import Image from 'next/image';
import { Expectation } from '@/types/worker';

interface ExpectationsListProps {
  expectations: Expectation[];
}

export function ExpectationsList({ expectations }: ExpectationsListProps) {
  return (
    <div className="flex flex-col w-full items-start gap-4 relative">
      <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0] leading-[normal] whitespace-nowrap">
        Expectations
      </h2>
      <div className="flex gap-1 w-full flex-col items-start relative">
        {expectations.map((expectation) => (
          <div
            key={expectation.id}
            className="flex items-center justify-between relative w-full"
          >
            <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
              {expectation.text}
            </div>
            {expectation.accepted ? (
              <div className="relative w-[24.0px] h-[24.0px] bg-[url(/mm-check-mark-150dpi-2.png)] bg-cover bg-[50%_50%]" />
            ) : (
              <div className="relative w-6 h-6 bg-[url(/20230601-mm-iconography-close1.png)] bg-cover bg-[50%_50%]" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}