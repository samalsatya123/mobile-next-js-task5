import Image from 'next/image';
import { Button } from './ui/button';

export function InterestButton() {
  return (
    <div className="flex flex-col items-start gap-2 relative w-full">
      <Button className="flex h-11 items-center justify-center px-6 py-3 relative w-full bg-main-colorprimary-blue rounded-[50px] h-auto hover:bg-main-colorprimary-blue/90 transition-colors">
        <div className="relative w-5 h-4 mr-2">
          <Image
            src="/screen-shot-2020-06-16-at-9-51-05-pm-copy.png"
            alt="Interest icon"
            width={20}
            height={16}
            className="object-contain"
          />
        </div>
        <div className="relative w-[104px] h-4 [font-family:'Cooper_BT-Medium',Helvetica] font-medium text-main-colorwhite text-base text-center tracking-[0] leading-[1px]">
          I&apos;m Interested
        </div>
      </Button>
    </div>
  );
}