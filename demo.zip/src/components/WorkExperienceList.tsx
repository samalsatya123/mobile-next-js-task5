import Image from 'next/image';
import { WorkExperience } from '@/types/worker';
import { Badge } from './ui/badge';

interface WorkExperienceListProps {
  experiences: WorkExperience[];
}

export function WorkExperienceList({ experiences }: WorkExperienceListProps) {
  return (
    <div className="flex flex-col w-full items-start gap-4 relative">
      <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0] leading-[normal] whitespace-nowrap">
        Work Experience
      </h2>
      <div className="flex flex-col items-start gap-[38px] relative w-full">
        {experiences.map((experience) => (
          <article
            key={experience.id}
            className="flex items-start gap-2 relative w-full"
          >
            <div
              className="relative w-[34px] h-[34px] bg-cover bg-center flex-shrink-0"
              style={{ backgroundImage: `url(${experience.icon})` }}
            />
            <div className="inline-flex flex-col items-start gap-6 relative flex-1">
              <div className="relative w-full mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-4">
                <span className="font-medium text-black leading-[0.1px]">
                  {experience.title}
                  <br />
                </span>
                <span className="font-medium text-[#898989] leading-[20.8px]">
                  {experience.period}
                </span>
              </div>

              <div className="inline-flex flex-col items-start gap-5 relative w-full">
                <div className="inline-flex items-start gap-5 relative w-full">
                  <div className="inline-flex flex-col items-start gap-1 relative flex-1">
                    <div className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] whitespace-nowrap">
                      EMPLOYER NATIONALITY
                    </div>
                    <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                      {experience.employerNationality}
                    </div>
                  </div>
                  <div className="inline-flex flex-col items-start gap-1 relative flex-1">
                    <div className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] whitespace-nowrap">
                      SIZE OF HOME
                    </div>
                    <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                      {experience.homeSize}
                    </div>
                  </div>
                </div>

                <div className="inline-flex items-start gap-5 relative w-full">
                  <div className="inline-flex flex-col items-start gap-1 relative flex-1">
                    <div className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] whitespace-nowrap">
                      DISTRICT
                    </div>
                    <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                      {experience.district}
                    </div>
                  </div>
                  <div className="inline-flex flex-col items-start gap-1 relative flex-1">
                    <div className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] whitespace-nowrap">
                      HOUSEHOLD SIZE
                    </div>
                    <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                      {experience.householdSize}
                    </div>
                  </div>
                </div>

                <div className="flex gap-1 w-full flex-col items-start relative">
                  <div className="relative w-[131px] mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal]">
                    LANGUAGE SPOKEN
                  </div>
                  <div className="relative w-full [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[20.8px]">
                    {experience.languageSpoken}
                  </div>
                </div>

                <div className="inline-flex items-start gap-1 relative">
                  <div className="inline-flex flex-col items-start gap-[5px] relative">
                    <div className="relative w-[131px] mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal]">
                      REASON FOR LEAVING
                    </div>
                    <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                      {experience.reasonForLeaving}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-1 w-full flex-col items-start relative">
                <div className="relative w-[140px] mt-[-1.00px] opacity-80 [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal]">
                  MAIN DUTIES
                </div>
                <div className="flex flex-wrap gap-2">
                  {experience.duties.map((duty) => (
                    <Badge
                      key={duty.id}
                      variant="outline"
                      className="inline-flex items-center gap-2.5 pl-[15px] pr-5 py-2 relative bg-main-colorwhite rounded-[44px] border border-solid border-[#eaeaea] shadow-white-button-shadow"
                    >
                      <div
                        className="relative w-6 h-6 bg-cover bg-center"
                        style={{ backgroundImage: `url(${duty.icon})` }}
                      />
                      <div className="relative w-fit [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
                        {duty.title}
                      </div>
                      {duty.subtitle && (
                        <div className="relative w-fit opacity-80 [font-family:'Mabry_Pro-Bold',Helvetica] font-bold text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] whitespace-nowrap">
                          {duty.subtitle}
                        </div>
                      )}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}