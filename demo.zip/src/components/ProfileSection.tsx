import { WorkerDetail } from '@/types/worker';
import { InfoCard } from './InfoCard';
import { SkillGrid } from './SkillGrid';
import { WorkExperienceList } from './WorkExperienceList';
import { ExpectationsList } from './ExpectationsList';
import { ExpandedProfile } from './ExpandedProfile';
import { InterestButton } from './InterestButton';

interface ProfileSectionProps {
  worker: WorkerDetail;
}

export function ProfileSection({ worker }: ProfileSectionProps) {
  const profileData = [
    [
      { label: "AGE", value: worker.age.toString() },
      { label: "NATIONALITY", value: worker.nationality },
    ],
    [
      { label: "HEIGHT", value: `${worker.height}cm` },
      { label: "CHINESE HOROSCOPE", value: worker.chineseHoroscope },
    ],
    [
      { label: "WEIGHT", value: `${worker.weight}kg` },
      { label: "HOROSCOPE", value: worker.horoscope },
    ],
    [
      { label: "RELIGION", value: worker.religion },
      { label: "MARITAL STATUS", value: worker.maritalStatus },
    ],
  ];

  const familyBackground = [
    { label: "NUMBER OF CHILDREN", value: worker.numberOfChildren.toString() },
    { label: "AGE OF OLDEST CHILD", value: worker.ageOfOldestChild.toString() },
  ];

  const educationItems = [
    {
      icon: "/mm-minimum-education-minimum-education-150dpi.png",
      label: "EDUCATION LEVEL",
      value: worker.educationLevel,
    },
    {
      icon: "/mm-specialty-course-specialty-course-150dpi.png",
      label: "SPECIAL COURSEWORK",
      value: worker.specialCoursework,
    },
  ];

  return (
    <div className="flex flex-col w-full items-center justify-between gap-8 relative px-5">
      <InfoCard title="Profile" data={profileData} />
      <InfoCard title="Family Background" data={familyBackground} />
      
      <div className="flex flex-col w-full items-start gap-4 relative">
        <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-grey-4 text-xl tracking-[0] leading-[normal] whitespace-nowrap">
          Education
        </h2>
        <div className="inline-flex flex-col items-start gap-4 relative">
          {educationItems.map((item, index) => (
            <div
              key={index}
              className="inline-flex items-start gap-2.5 relative"
            >
              <div
                className="relative w-[34px] h-[34px] bg-cover bg-center"
                style={{ backgroundImage: `url(${item.icon})` }}
              />
              <div className="inline-flex flex-col items-start gap-1 relative">
                <div className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Medium',Helvetica] font-medium text-neutrals-colorneutrals-grey-4 text-[10px] tracking-[0] leading-[normal] whitespace-nowrap">
                  {item.label}
                </div>
                <div className="relative w-[259px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[20.8px]">
                  {item.value}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col w-full items-start gap-3 relative">
        <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0] leading-[normal] whitespace-nowrap">
          Language
        </h2>
        <div className="inline-flex gap-2.5 flex-col items-start relative">
          <p className="relative w-[295px] mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal]">
            {worker.languages.join(', ')}
          </p>
        </div>
      </div>

      <SkillGrid skills={worker.mainSkills} />

      <div className="flex flex-col w-full items-start gap-3 relative">
        <h2 className="relative w-fit mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-[#898989] text-xl tracking-[0] leading-[normal] whitespace-nowrap">
          Cooking
        </h2>
        <div className="inline-flex flex-col items-start gap-5 relative">
          <p className="relative w-[295px] mt-[-1.00px] [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal]">
            {worker.cookingSkills.join(', ')}
          </p>
        </div>
      </div>

      <WorkExperienceList experiences={worker.workExperience} />
      <ExpectationsList expectations={worker.expectations} />
      <ExpandedProfile sections={worker.expandedProfile} />

      {worker.hasReferenceLetter && (
        <p className="relative w-full [font-family:'Mabry_Pro-Regular',Helvetica] font-normal text-neutrals-colorneutrals-black text-base tracking-[0] leading-[normal]">
          Reference Letter Available
        </p>
      )}

      <InterestButton />
    </div>
  );
}