import { Suspense } from 'react';
import { fetchWorkerDetail } from '@/lib/api';
import { MobileHeader } from '@/components/MobileHeader';
import { ProfileHeader } from '@/components/ProfileHeader';
import { ProfileSection } from '@/components/ProfileSection';
import { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  try {
    const worker = await fetchWorkerDetail();
    
    return {
      title: `${worker.name} - Professional Domestic Helper | MaidMatch`,
      description: `Meet ${worker.name}, a ${worker.age}-year-old ${worker.nationality} domestic helper with ${worker.yearsOfExperience} years of experience. Skilled in ${worker.mainSkills.slice(0, 3).map(s => s.title).join(', ')} and more.`,
      openGraph: {
        title: `${worker.name} - Professional Domestic Helper`,
        description: `${worker.age}-year-old ${worker.nationality} with ${worker.yearsOfExperience} years of experience`,
        images: [
          {
            url: worker.profileImage,
            width: 400,
            height: 400,
            alt: `${worker.name} profile picture`,
          },
        ],
      },
    };
  } catch (error) {
    return {
      title: 'Professional Domestic Helper Profile | MaidMatch',
      description: 'View detailed profile of an experienced domestic helper',
    };
  }
}

function LoadingSkeleton() {
  return (
    <div className="w-full max-w-[375px] mx-auto min-h-screen animate-pulse">
      <div className="h-20 bg-gray-200 mb-4" />
      <div className="h-[203px] bg-gray-200 mb-6" />
      <div className="px-5 space-y-6">
        <div className="h-8 bg-gray-200 rounded" />
        <div className="h-32 bg-gray-200 rounded" />
        <div className="h-24 bg-gray-200 rounded" />
      </div>
    </div>
  );
}

export default async function HomePage() {
  const worker = await fetchWorkerDetail();

  return (
    <main className="w-full max-w-[375px] mx-auto min-h-screen bg-[#fff]">
      {/* <MobileHeader /> */}
      <ProfileHeader worker={worker} />
      <Suspense fallback={<LoadingSkeleton />}>
        <ProfileSection worker={worker} />
      </Suspense>
    </main>
  );
}