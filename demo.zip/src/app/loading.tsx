export default function Loading() {
  return (
    <div className="w-full max-w-[375px] mx-auto min-h-screen animate-pulse">
      <div className="h-20 bg-gray-200 mb-4" />
      <div className="h-[203px] bg-gray-200 mb-6" />
      <div className="px-5 space-y-6">
        <div className="h-8 bg-gray-200 rounded" />
        <div className="h-32 bg-gray-200 rounded" />
        <div className="h-24 bg-gray-200 rounded" />
        <div className="h-16 bg-gray-200 rounded" />
        <div className="h-20 bg-gray-200 rounded" />
      </div>
    </div>
  );
}