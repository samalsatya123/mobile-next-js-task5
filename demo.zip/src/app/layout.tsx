import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import '../styles/globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'MaidMatch - Professional Domestic Helper Profiles',
  description: 'Find experienced and qualified domestic helpers through MaidMatch. Browse detailed profiles, work experience, and skills to find the perfect match for your household needs.',
  keywords: 'domestic helper, maid, housekeeper, caregiver, Hong Kong, professional cleaning, childcare',
  authors: [{ name: 'MaidMatch' }],
  openGraph: {
    title: 'MaidMatch - Professional Domestic Helper Profiles',
    description: 'Find experienced and qualified domestic helpers through MaidMatch.',
    url: 'https://maidmatch.ai',
    siteName: 'MaidMatch',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'MaidMatch - Professional Domestic Helper Profiles',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MaidMatch - Professional Domestic Helper Profiles',
    description: 'Find experienced and qualified domestic helpers through MaidMatch.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css?family=Inter:500"
          rel="stylesheet"
        />
      </head>
      <body className={inter.className}>
        <div className="min-h-screen bg-gray-50">
          {children}
        </div>
      </body>
    </html>
  );
}