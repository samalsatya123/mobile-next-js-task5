import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="w-full max-w-[375px] mx-auto min-h-screen flex flex-col items-center justify-center px-5">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Profile Not Found</h2>
        <p className="text-gray-600">
          The profile you&apos;re looking for doesn&apos;t exist or has been removed.
        </p>
        <Button asChild className="bg-main-colorprimary-blue hover:bg-main-colorprimary-blue/90">
          <Link href="/">
            Return Home
          </Link>
        </Button>
      </div>
    </div>
  );
}