import { ApiResponse, WorkerDetail } from '@/types/worker';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;
const WORKER_ENDPOINT = process.env.WORKER_DETAIL_ENDPOINT;

export async function fetchWorkerDetail(): Promise<WorkerDetail> {
  if (!API_BASE_URL || !WORKER_ENDPOINT) {
    throw new Error('API configuration is missing');
  }

  const url = `${API_BASE_URL}${WORKER_ENDPOINT}`;
  
  try {
    const response = await fetch(url, {
      next: { revalidate: 3600 }, // Revalidate every hour
      headers: {
        'Content-Type': 'application/json',
      },
    });

if (!response.ok) {
  console.warn(`HTTP error! status: ${response.status}. Falling back to mock data.`);
  return getMockWorkerData();
}

    const data: ApiResponse = await response.json();
    
    if (!data.success) {
      throw new Error(data.message || 'API request failed');
    }

    return data.data;
  } catch (error) {
    console.error('Error fetching worker detail:', error);
    // Return mock data as fallback
    return getMockWorkerData();
  }
}

// Mock data based on the current implementation
function getMockWorkerData(): WorkerDetail {
  return {
    id: 1058,
    name: "Angelissa",
    age: 34,
    nationality: "Indonesian",
    height: 155,
    weight: 47,
    religion: "Christian",
    maritalStatus: "Married",
    chineseHoroscope: "Dog",
    horoscope: "Libra",
    numberOfChildren: 2,
    ageOfOldestChild: 15,
    educationLevel: "University of the Philippines, Los Banos Communications",
    specialCoursework: "Caregiving",
    languages: ["English", "Cantonese"],
    yearsOfExperience: 10,
    canStartDate: "April 20",
    location: "Hong Kong",
    profileImage: "/ellipse-2.png",
    backgroundImage: "/mm-profile-bg-delivery-pink-150dpi.png",
    hasReferenceLetter: true,
    mainSkills: [
      {
        id: "baby-care",
        title: "Baby Care",
        subtitle: "AGE 0-1",
        image: "/screen-shot-2020-07-30-at-3-55-25-pm.png",
        category: "care"
      },
      {
        id: "toddler-care",
        title: "Toddler Care",
        subtitle: "AGE 2-5",
        image: "/screen-shot-2020-07-30-at-3-55-31-pm.png",
        category: "care"
      },
      {
        id: "elderly-care",
        title: "Elderly Care",
        subtitle: "AGE 65+",
        image: "/screen-shot-2020-07-30-at-3-55-39-pm.png",
        category: "care"
      },
      {
        id: "cooking",
        title: "Cooking",
        subtitle: "",
        image: "/screen-shot-2020-06-16-at-12-49-41-am.png",
        category: "household"
      },
      {
        id: "gardening",
        title: "Gardening",
        subtitle: "",
        image: "/screen-shot-2020-06-16-at-12-50-08-am.png",
        category: "household"
      },
      {
        id: "driving",
        title: "Driving",
        subtitle: "",
        image: "/screen-shot-2020-06-16-at-12-49-16-am.png",
        category: "other"
      }
    ],
    cookingSkills: ["Filipino Cuisine", "Chinese Cuisine"],
    workExperience: [
      {
        id: "hk-2018-2020",
        title: "Domestic Helper, Hong Kong",
        period: "June 2018 - June 2020",
        location: "Hong Kong",
        employerNationality: "Hong Kong",
        district: "Wanchai",
        householdSize: 4,
        homeSize: "500 Sq Ft",
        languageSpoken: "Cantonese",
        reasonForLeaving: "Finished Contract",
        icon: "/mm-work-experience-150dpi-1.png",
        duties: [
          {
            id: "child-care",
            title: "Child Care",
            subtitle: "AGE 6-12",
            icon: "/mm-child-care-color-child-care-150dpi.png"
          },
          {
            id: "elderly-care",
            title: "Elderly Care",
            subtitle: "AGE 6-12",
            icon: "/mm-elderly-care-elderly-care-150dpi.png"
          },
          {
            id: "cooking",
            title: "Cooking",
            subtitle: "",
            icon: "/mm-cooking-cooking-150dpi-1.png"
          },
          {
            id: "housework",
            title: "General Housework",
            subtitle: "",
            icon: "/mm-household-chores-2-household-chores-2-150dpi.png"
          }
        ]
      },
      {
        id: "tw-2016-2018",
        title: "Domestic Helper, Taiwan",
        period: "July 2016 - May 2018",
        location: "Taiwan",
        employerNationality: "Hong Kong",
        district: "Wanchai",
        householdSize: 4,
        homeSize: "500 Sq Ft",
        languageSpoken: "Cantonese",
        reasonForLeaving: "Terminated Contract (Pass Away)",
        icon: "/mm-overseas-experience-overseas-experience-150dpi.png",
        duties: [
          {
            id: "teen-care",
            title: "Teen Care",
            subtitle: "AGE 13-18",
            icon: "/mm-teen-care-teen-care-150dpi.png"
          },
          {
            id: "cooking",
            title: "Cooking",
            subtitle: "",
            icon: "/mm-cooking-cooking-150dpi-1.png"
          },
          {
            id: "pet-care",
            title: "Pet Care",
            subtitle: "",
            icon: "/mm-pet-care-pet-care-150dpi.png"
          }
        ]
      }
    ],
    expectations: [
      { id: "newborn", text: "Take care of newborn baby", accepted: true },
      { id: "share-room", text: "Willing to share room", accepted: true },
      { id: "co-worker", text: "Co-worker", accepted: false },
      { id: "saturday-off", text: "Saturday Off", accepted: true }
    ],
    expandedProfile: [
      {
        id: "baby-care",
        title: "Baby Care",
        sections: [
          {
            label: "HAS CARED FOR",
            content: "Newborn (0-1 year)\nInfant (1-3 years)\nToddler (3-5 years)\nChild (5-12 years)\nTeen (13-19 years)"
          },
          {
            label: "EXPERIENCED IN",
            content: "Changing diapers \nFeeding\nPreparing food\nSterilising bottles \nNight care for baby\nNight care for toddler / child\nCaring for child with Special Needs"
          }
        ]
      },
      {
        id: "elderly-care",
        title: "Elderly Care",
        sections: [
          {
            label: "HAS CARED FOR",
            content: "75 yr old"
          },
          {
            label: "EXPERIENCED IN",
            content: "Assisting with daily activities\nMedication management\nMonitoring health (e.g. blood pressure)\nMobility assistance (e.g. wheelchair)\nMeal preparation\nAssisting with physical therapy\nCare for elderly with Special Needs"
          }
        ]
      },
      {
        id: "household-chores",
        title: "Household Chores",
        sections: [
          {
            label: "EXPERIENCED IN",
            content: "General cleaning \nFurniture care\nWashing machine\nBed making\nWindow cleaning\nIroning\nSewing\nHand washing (clothes)\nFloor cleaning\nVacuum cleaning"
          }
        ]
      }
    ]
  };
}
