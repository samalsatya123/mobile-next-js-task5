export interface WorkerDetail {
  id: number;
  name: string;
  age: number;
  nationality: string;
  height: number;
  weight: number;
  religion: string;
  maritalStatus: string;
  chineseHoroscope: string;
  horoscope: string;
  numberOfChildren: number;
  ageOfOldestChild: number;
  educationLevel: string;
  specialCoursework: string;
  languages: string[];
  mainSkills: Skill[];
  cookingSkills: string[];
  workExperience: WorkExperience[];
  expectations: Expectation[];
  expandedProfile: ExpandedProfileSection[];
  profileImage: string;
  backgroundImage: string;
  canStartDate: string;
  location: string;
  yearsOfExperience: number;
  hasReferenceLetter: boolean;
}

export interface Skill {
  id: string;
  title: string;
  subtitle?: string;
  image: string;
  category: 'care' | 'household' | 'other';
}

export interface WorkExperience {
  id: string;
  title: string;
  period: string;
  location: string;
  employerNationality: string;
  district: string;
  householdSize: number;
  homeSize: string;
  languageSpoken: string;
  reasonForLeaving: string;
  duties: Duty[];
  icon: string;
}

export interface Duty {
  id: string;
  title: string;
  subtitle?: string;
  icon: string;
}

export interface Expectation {
  id: string;
  text: string;
  accepted: boolean;
}

export interface ExpandedProfileSection {
  id: string;
  title: string;
  sections: ExpandedSubSection[];
}

export interface ExpandedSubSection {
  label: string;
  content: string;
}

// API Response type
export interface ApiResponse {
  success: boolean;
  data: WorkerDetail;
  message?: string;
}